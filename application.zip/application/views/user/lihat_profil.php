 <section class="content">
       <div class="container-fluid">
 <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                PROFIL
                                      </h2>
                           
                        </div>
                        <div class="body">
                            <div class="row">
                                <div class="col-sm-6 col-md-3">
                                    <div class="thumbnail">
                                        <img src="<?php echo base_url();?>assets/images/profile.jpg">
                                        <div class="caption">
                                            <h3>Thumbnail label</h3>
                                            <p>
                                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
                                                text ever since the 1500s
                                            </p>
                                            <p>
                                              
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="thumbnail">
                                        <img src="<?php echo base_url();?>assets/images/profile.jpg">
                                        <div class="caption">
                                            <h3>Thumbnail label</h3>
                                            <p>
                                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
                                                text ever since the 1500s
                                            </p>
                                            <p>
                                              
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="thumbnail">
                                        <img src="<?php echo base_url();?>assets/images/profile.jpg">
                                        <div class="caption">
                                            <h3>Thumbnail label</h3>
                                            <p>
                                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
                                                text ever since the 1500s
                                            </p>
                                            <p>
                                               
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-3">
                                    <div class="thumbnail">
                                        <img src="<?php echo base_url();?>assets/images/profile.jpg">
                                        <div class="caption">
                                            <h3>Thumbnail label</h3>
                                            <p>
                                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
                                                text ever since the 1500s
                                            </p>
                                            <p>
                                               
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
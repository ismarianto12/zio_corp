 <div class="legal">
                <div class="copyright">
                    &copy; 2019 <a href="javascript:void(0);">Keban Center</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 1.0.5
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        <aside id="rightsidebar" class="right-sidebar"><ul class="nav nav-tabs tab-nav-right" role="tablist"><li role="presentation" class="active"><a href="#settings" data-toggle="tab">SETTINGS</a></li>
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane fade in active in active" id="settings">
                    <div class="demo-settings">
                        <p>SHUTDOWN</p>
                        <ul class="setting-list"><li>
                            <span><a alt="Logout" href="<?php echo site_url('login/process_logout');?>"><i class="material-icons">power_settings_new</i>Logout</a></span>                            </li>
                        </ul>
                         
                    </div>
              </div>
          </div>
        </aside>
        <!-- #END# Right Sidebar -->
    </section>
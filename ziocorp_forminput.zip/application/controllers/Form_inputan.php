<?php

/*developed by ismarianto putra
  you can visit my site in ismarianto.com
  for more complain anda more information.  
*/

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Form_inputan extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model(['Form_inputan_model','m_user']);
		$this->load->library('form_validation');
		$this->load->library('datatables');
	}

	public function index()
	{
		$id_user         = $this->session->id_user;
		$login           = $this->session->login;
		$x['rs_user']    = $this->m_user->get($id_user);
		$x['page_title'] = 'Data : Form inputan';
		if ($id_user != '' || $login != '') { 
			$this->template->load('template', 'form_inputan/form_inputan_list', $x);
		} else {
			show_404();
			die();
		}
	}

	public function json()
	{
		$id_user = $this->session->id_user;
		$login   = $this->session->login;

		if ($id_user != '' || $login != '') {
			header('Content-Type: application/json');
			echo $this->Form_inputan_model->json();
		} else {
			show_404();
			die();
		}
	}

	public function detail($id)
	{ 
		error_reporting(0);
		$row = $this->Form_inputan_model->get_by_id($id);
		if ($row) {
			$data = array(
				'id' => $row->id,
				'nama' => $row->nama,
				'email' => $row->email,
				'alamat' => $row->alamat,
				'nomor_pendaftaran' => $row->nomor_pendaftaran,
				'area' => $row->area,
				'penerima' => $row->penerima,
				'alamatpen' => $row->alamatpen,
				'tanggal' => $row->tanggal,
				'transportasi_angkutan' => $row->transportasi_angkutan,
				'keterangan' => $row->keterangan,
				'nilai' => $row->nilai,
				'jenis1' => $row->jenis1,
				'ukuran1' => $row->ukuran1,
				'jumlah1' => $row->jumlah1,
				'satuan1' => $row->satuan1,
				'keterangan1' => $row->keterangan1,
				'jenis2' => $row->jenis2,
				'ukuran2' => $row->ukuran2,
				'jumlah2' => $row->jumlah2,
				'satuan2' => $row->satuan2,
				'keterangan2' => $row->keterangan2,
				'jenis3' => $row->jenis3,
				'ukuran3' => $row->ukuran3,
				'jumlah3' => $row->jumlah3,
				'satuan3' => $row->satuan3,
				'keterangan3' => $row->keterangan3,
				'jenis4' => $row->jenis4,
				'ukuran4' => $row->ukuran4,
				'jumlah4' => $row->jumlah4,
				'satuan4' => $row->satuan4,
				'keterangan4' => $row->keterangan4,
				'jenis5' => $row->jenis5,
				'ukuran5' => $row->ukuran5,
				'jumlah5' => $row->jumlah5,
				'satuan5' => $row->satuan5,
				'keterangan5' => $row->keterangan5,
				'user_id' => $row->user_id,
				'date_created' => $row->date_created,
				'date_updated' => $row->date_updated,

				'page_title' => 'Detail DATA FORM INPUTAN ' . ucfirst($row->nama),
			);
			$this->template->load('template', 'form_inputan/form_inputan_read', $data);
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-warniing fade-in">Data Tidak Di Temukan.</div>');
			redirect(site_url('form_inputan'));
		}
	}

	public function tambah()
	{
		$id_user            = $this->session->id_user;
		$login              = $this->session->login;
		$x['rs_user']       = $this->m_user->get($id_user);
		$x['page_title']    = 'Data : Form inputan'; 

		if ($id_user != '' || $login != '') { 
			$x['rs_user']   = $this->m_user->get($id_user); 
		}else{
			error_reporting(0);
		}
		$data = array( 
			'page_title' => 'Tambah Form inputan',
			'button' => 'Create',
			'action' => site_url('form_inputan/tambah_data'),
			'id' => set_value('id'),
			'nama' => set_value('nama'),
			'email' => set_value('email'),
			'alamat' => set_value('alamat'),
			'nomor_pendaftaran' => set_value('nomor_pendaftaran'),
			'area' => set_value('area'),
			'penerima' => set_value('penerima'),
			'alamatpen' => set_value('alamatpen'),
			'tanggal' => set_value('tanggal'),
			'transportasi_angkutan' => set_value('transportasi_angkutan'),
			'keterangan' => set_value('keterangan'),
			'nilai' => set_value('nilai'),
			'jenis1' => set_value('jenis1'),
			'ukuran1' => set_value('ukuran1'),
			'jumlah1' => set_value('jumlah1'),
			'satuan1' => set_value('satuan1'),
			'keterangan1' => set_value('keterangan1'),
			'jenis2' => set_value('jenis2'),
			'ukuran2' => set_value('ukuran2'),
			'jumlah2' => set_value('jumlah2'),
			'satuan2' => set_value('satuan2'),
			'keterangan2' => set_value('keterangan2'),
			'jenis3' => set_value('jenis3'),
			'ukuran3' => set_value('ukuran3'),
			'jumlah3' => set_value('jumlah3'),
			'satuan3' => set_value('satuan3'),
			'keterangan3' => set_value('keterangan3'),
			'jenis4' => set_value('jenis4'),
			'ukuran4' => set_value('ukuran4'),
			'jumlah4' => set_value('jumlah4'),
			'satuan4' => set_value('satuan4'),
			'keterangan4' => set_value('keterangan4'),
			'jenis5' => set_value('jenis5'),
			'ukuran5' => set_value('ukuran5'),
			'jumlah5' => set_value('jumlah5'),
			'satuan5' => set_value('satuan5'),
			'keterangan5' => set_value('keterangan5'),
			'user_id' => set_value('user_id'),
			'date_created' => set_value('date_created'),
			'date_updated' => set_value('date_updated'),
		);
		$this->template->load('template', 'form_inputan/form_inputan_form', array_merge($data,$x));
	}

	public function tambah_data()
	{
		$this->_rules();
		if ($this->form_validation->run() == FALSE) {
			//$this->tambah();
			redirect($this->input->post('redirect'));
		} else {
			$data = array( 
				'nama' => $this->input->post('nama', TRUE),
				'email' => $this->input->post('email', TRUE),
				'alamat' => $this->input->post('alamat', TRUE),
				'nomor_pendaftaran' => $this->input->post('nomor_pendaftaran', TRUE),
				'area' => $this->input->post('area', TRUE),
				'penerima' => $this->input->post('penerima', TRUE),
				'alamatpen' => $this->input->post('alamatpen', TRUE),
				'tanggal' => $this->input->post('tanggal', TRUE),
				'transportasi_angkutan' => $this->input->post('transportasi_angkutan', TRUE),
				'keterangan' => $this->input->post('keterangan', TRUE),
				'nilai' => $this->input->post('nilai', TRUE),
				'jenis1' => $this->input->post('jenis1', TRUE),
				'ukuran1' => $this->input->post('ukuran1', TRUE),
				'jumlah1' => $this->input->post('jumlah1', TRUE),
				'satuan1' => $this->input->post('satuan1', TRUE),
				'keterangan1' => $this->input->post('keterangan1', TRUE),
				'jenis2' => $this->input->post('jenis2', TRUE),
				'ukuran2' => $this->input->post('ukuran2', TRUE),
				'jumlah2' => $this->input->post('jumlah2', TRUE),
				'satuan2' => $this->input->post('satuan2', TRUE),
				'keterangan2' => $this->input->post('keterangan2', TRUE),
				'jenis3' => $this->input->post('jenis3', TRUE),
				'ukuran3' => $this->input->post('ukuran3', TRUE),
				'jumlah3' => $this->input->post('jumlah3', TRUE),
				'satuan3' => $this->input->post('satuan3', TRUE),
				'keterangan3' => $this->input->post('keterangan3', TRUE),
				'jenis4' => $this->input->post('jenis4', TRUE),
				'ukuran4' => $this->input->post('ukuran4', TRUE),
				'jumlah4' => $this->input->post('jumlah4', TRUE),
				'satuan4' => $this->input->post('satuan4', TRUE),
				'keterangan4' => $this->input->post('keterangan4', TRUE),
				'jenis5' => $this->input->post('jenis5', TRUE),
				'ukuran5' => $this->input->post('ukuran5', TRUE),
				'jumlah5' => $this->input->post('jumlah5', TRUE),
				'satuan5' => $this->input->post('satuan5', TRUE),
				'keterangan5' => $this->input->post('keterangan5', TRUE),
				'user_id' => $this->input->post('user_id', TRUE),
				'date_created' => $this->input->post('date_created', TRUE),
				'date_updated' => $this->input->post('date_updated', TRUE),
			);

			$this->Form_inputan_model->insert($data);
			$this->session->set_flashdata('message', '<div class="alert alert-success fade-in"><i class="fa fa-check"></i>Data Berhasil Di Tambahkan.</div>');
			$id = $this->selectmax_forminputan();

			print_r($this->input->post('redirect') . '/detail/' . $id);
		}
	}
	private function selectmax_forminputan()
	{
		$data = $this->db->select_max('id')
			->from('form_inputan')
			->get();
		return $data->row()->id;
	}


	public function edit($id)
	{ 
		$id_user            = $this->session->id_user;
		$login              = $this->session->login;
		$x['rs_user']    = $this->m_user->get($id_user);
		$x['page_title'] = 'Data : Form inputan';

		if ($id_user != '' || $login != '') { 

			$row = $this->Form_inputan_model->get_by_id($id);

			if ($row) {
				$data = array(
					'page_title' => 'Data FORM_INPUTAN',
					'button' => 'Update',
					'action' => site_url('form_inputan/edit_data'),
					'id' => set_value('id', $row->id),
					'nama' => set_value('nama', $row->nama),
					'email' => set_value('email', $row->email),
					'alamat' => set_value('alamat', $row->alamat),
					'nomor_pendaftaran' => set_value('nomor_pendaftaran', $row->nomor_pendaftaran),
					'area' => set_value('area', $row->area),
					'penerima' => set_value('penerima', $row->penerima),
					'alamatpen' => set_value('alamatpen', $row->alamatpen),
					'tanggal' => set_value('tanggal', $row->tanggal),
					'transportasi_angkutan' => set_value('transportasi_angkutan', $row->transportasi_angkutan),
					'keterangan' => set_value('keterangan', $row->keterangan),
					'nilai' => set_value('nilai', $row->nilai),
					'jenis1' => set_value('jenis1', $row->jenis1),
					'ukuran1' => set_value('ukuran1', $row->ukuran1),
					'jumlah1' => set_value('jumlah1', $row->jumlah1),
					'satuan1' => set_value('satuan1', $row->satuan1),
					'keterangan1' => set_value('keterangan1', $row->keterangan1),
					'jenis2' => set_value('jenis2', $row->jenis2),
					'ukuran2' => set_value('ukuran2', $row->ukuran2),
					'jumlah2' => set_value('jumlah2', $row->jumlah2),
					'satuan2' => set_value('satuan2', $row->satuan2),
					'keterangan2' => set_value('keterangan2', $row->keterangan2),
					'jenis3' => set_value('jenis3', $row->jenis3),
					'ukuran3' => set_value('ukuran3', $row->ukuran3),
					'jumlah3' => set_value('jumlah3', $row->jumlah3),
					'satuan3' => set_value('satuan3', $row->satuan3),
					'keterangan3' => set_value('keterangan3', $row->keterangan3),
					'jenis4' => set_value('jenis4', $row->jenis4),
					'ukuran4' => set_value('ukuran4', $row->ukuran4),
					'jumlah4' => set_value('jumlah4', $row->jumlah4),
					'satuan4' => set_value('satuan4', $row->satuan4),
					'keterangan4' => set_value('keterangan4', $row->keterangan4),
					'jenis5' => set_value('jenis5', $row->jenis5),
					'ukuran5' => set_value('ukuran5', $row->ukuran5),
					'jumlah5' => set_value('jumlah5', $row->jumlah5),
					'satuan5' => set_value('satuan5', $row->satuan5),
					'keterangan5' => set_value('keterangan5', $row->keterangan5),
					'user_id' => set_value('user_id', $row->user_id),
					'date_created' => set_value('date_created', $row->date_created),
					'date_updated' => set_value('date_updated', $row->date_updated),
				);
				$this->template->load('template', 'form_inputan/form_inputan_form', array_merge($data,$x));
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-info fade-in">Data Tidak Di Temukan.</div>');
				redirect(site_url('form_inputan'));
			}
		} else {
			show_404();
			die();
		}
	}

	public function edit_data()
	{

		$id_user = $this->session->id_user;
		$login   = $this->session->login;

		if ($id_user != '' || $login != '') {

			$this->_rules();

			if ($this->form_validation->run() == FALSE) {
				$this->edit($this->input->post('id', TRUE));
			} else {
				$data = array(
					'nama' => $this->input->post('nama', TRUE),
					'email' => $this->input->post('email', TRUE),
					'alamat' => $this->input->post('alamat', TRUE),
					'nomor_pendaftaran' => $this->input->post('nomor_pendaftaran', TRUE),
					'area' => $this->input->post('area', TRUE),
					'penerima' => $this->input->post('penerima', TRUE),
					'alamatpen' => $this->input->post('alamatpen', TRUE),
					'tanggal' => $this->input->post('tanggal', TRUE),
					'transportasi_angkutan' => $this->input->post('transportasi_angkutan', TRUE),
					'keterangan' => $this->input->post('keterangan', TRUE),
					'nilai' => $this->input->post('nilai', TRUE),
					'jenis1' => $this->input->post('jenis1', TRUE),
					'ukuran1' => $this->input->post('ukuran1', TRUE),
					'jumlah1' => $this->input->post('jumlah1', TRUE),
					'satuan1' => $this->input->post('satuan1', TRUE),
					'keterangan1' => $this->input->post('keterangan1', TRUE),
					'jenis2' => $this->input->post('jenis2', TRUE),
					'ukuran2' => $this->input->post('ukuran2', TRUE),
					'jumlah2' => $this->input->post('jumlah2', TRUE),
					'satuan2' => $this->input->post('satuan2', TRUE),
					'keterangan2' => $this->input->post('keterangan2', TRUE),
					'jenis3' => $this->input->post('jenis3', TRUE),
					'ukuran3' => $this->input->post('ukuran3', TRUE),
					'jumlah3' => $this->input->post('jumlah3', TRUE),
					'satuan3' => $this->input->post('satuan3', TRUE),
					'keterangan3' => $this->input->post('keterangan3', TRUE),
					'jenis4' => $this->input->post('jenis4', TRUE),
					'ukuran4' => $this->input->post('ukuran4', TRUE),
					'jumlah4' => $this->input->post('jumlah4', TRUE),
					'satuan4' => $this->input->post('satuan4', TRUE),
					'keterangan4' => $this->input->post('keterangan4', TRUE),
					'jenis5' => $this->input->post('jenis5', TRUE),
					'ukuran5' => $this->input->post('ukuran5', TRUE),
					'jumlah5' => $this->input->post('jumlah5', TRUE),
					'satuan5' => $this->input->post('satuan5', TRUE),
					'keterangan5' => $this->input->post('keterangan5', TRUE),
					'user_id' => $this->input->post('user_id', TRUE),
					'date_created' => $this->input->post('date_created', TRUE),
					'date_updated' => $this->input->post('date_updated', TRUE),
				);

				$this->Form_inputan_model->update($this->input->post('id', TRUE), $data);
				$this->session->set_flashdata('message', '<div class="alert alert-success fade-in"><i class="fa fa-check"></i>Edit Data Berhasil.</div>');
				redirect(site_url('form_inputan'));
			}
		} else {
			show_404();
			die();
		}
	}

	public function hapus($id)
	{
		$row = $this->Form_inputan_model->get_by_id($id);

		if ($row) {
			$this->Form_inputan_model->delete($id);
			$this->session->set_flashdata('message', '<div class="alert alert-danger fade-in"><i class="fa fa-check"></i>Data Berhasil Di Hapus</div>');
			redirect(site_url('form_inputan'));
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-warniing fade-in">Ops Something Went Wrong Please Contact Administrator.</div>');
			redirect(site_url('form_inputan'));
		}
	}

	public function _rules()
	{
		$this->form_validation->set_rules('nama', 'nama', 'trim|required');
		$this->form_validation->set_rules('email', 'email', 'trim|required');
		$this->form_validation->set_rules('alamat', 'alamat', 'trim|required');
		$this->form_validation->set_rules('nomor_pendaftaran', 'nomor pendaftaran', 'trim|required');
		$this->form_validation->set_rules('area', 'area', 'trim|required');
		$this->form_validation->set_rules('penerima', 'penerima', 'trim|required');
		$this->form_validation->set_rules('alamatpen', 'alamatpen', 'trim|required');
		$this->form_validation->set_rules('tanggal', 'tanggal', 'trim|required');
		$this->form_validation->set_rules('transportasi_angkutan', 'transportasi angkutan', 'trim|required');
		$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');
		$this->form_validation->set_rules('nilai', 'nilai', 'trim|required');
		$this->form_validation->set_rules('jenis1', 'jenis1', 'trim|required');
		$this->form_validation->set_rules('ukuran1', 'ukuran1', 'trim|required');
		$this->form_validation->set_rules('jumlah1', 'jumlah1', 'trim|required');
		$this->form_validation->set_rules('satuan1', 'satuan1', 'trim|required');
		$this->form_validation->set_rules('keterangan1', 'keterangan1', 'trim|required');
		$this->form_validation->set_rules('jenis2', 'jenis2', 'trim|required');
		$this->form_validation->set_rules('ukuran2', 'ukuran2', 'trim|required');
		$this->form_validation->set_rules('jumlah2', 'jumlah2', 'trim|required');
		$this->form_validation->set_rules('satuan2', 'satuan2', 'trim|required');
		$this->form_validation->set_rules('keterangan2', 'keterangan2', 'trim|required');
		$this->form_validation->set_rules('jenis3', 'jenis3', 'trim|required');
		$this->form_validation->set_rules('ukuran3', 'ukuran3', 'trim|required');
		$this->form_validation->set_rules('jumlah3', 'jumlah3', 'trim|required');
		$this->form_validation->set_rules('satuan3', 'satuan3', 'trim|required');
		$this->form_validation->set_rules('keterangan3', 'keterangan3', 'trim|required');
		$this->form_validation->set_rules('jenis4', 'jenis4', 'trim|required');
		$this->form_validation->set_rules('ukuran4', 'ukuran4', 'trim|required');
		$this->form_validation->set_rules('jumlah4', 'jumlah4', 'trim|required');
		$this->form_validation->set_rules('satuan4', 'satuan4', 'trim|required');
		$this->form_validation->set_rules('keterangan4', 'keterangan4', 'trim|required');
		$this->form_validation->set_rules('jenis5', 'jenis5', 'trim|required');
		$this->form_validation->set_rules('ukuran5', 'ukuran5', 'trim|required');
		$this->form_validation->set_rules('jumlah5', 'jumlah5', 'trim|required');
		$this->form_validation->set_rules('satuan5', 'satuan5', 'trim|required');
		$this->form_validation->set_rules('keterangan5', 'keterangan5', 'trim|required');
		$this->form_validation->set_rules('redirect', 'redirect', 'required');

		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
	}
}
